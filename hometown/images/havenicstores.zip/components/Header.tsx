
import React, { useState, useEffect, useRef } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { ShoppingCartIcon, UserIcon, SearchIcon } from './icons';
import { api } from '../services/api';
import type { Product } from '../types';

const SearchBar: React.FC = () => {
    const [query, setQuery] = useState('');
    const [suggestions, setSuggestions] = useState<Product[]>([]);
    const [isOpen, setIsOpen] = useState(false);
    const navigate = useNavigate();
    const searchRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const fetchSuggestions = async () => {
            if (query.length > 1) {
                const results = await api.searchProducts(query);
                setSuggestions(results);
                setIsOpen(true);
            } else {
                setSuggestions([]);
                setIsOpen(false);
            }
        };

        const debounce = setTimeout(fetchSuggestions, 300);
        return () => clearTimeout(debounce);
    }, [query]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSelect = (productId: string) => {
        setQuery('');
        setSuggestions([]);
        setIsOpen(false);
        navigate(`/product/${productId}`);
    };

    return (
        <div className="relative w-full max-w-xs" ref={searchRef}>
            <div className="relative">
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search products..."
                    className="w-full pl-10 pr-4 py-2 text-sm bg-slate-100 border-2 border-transparent rounded-lg focus:outline-none focus:border-accent"
                />
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            </div>
            {isOpen && suggestions.length > 0 && (
                <div className="absolute z-20 w-full mt-1 bg-white rounded-lg shadow-lg overflow-hidden border border-slate-200">
                    <ul>
                        {suggestions.map(product => (
                            <li key={product.id}
                                onClick={() => handleSelect(product.id)}
                                className="px-4 py-2 flex items-center gap-3 hover:bg-slate-100 cursor-pointer transition-colors"
                            >
                                <img src={product.images[0]} alt={product.name} className="w-10 h-10 object-cover rounded-md"/>
                                <span className="text-sm font-medium">{product.name}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};


const Header: React.FC = () => {
  const { itemCount } = useCart();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`sticky top-0 z-50 w-full transition-all duration-300 ${isScrolled ? 'bg-white/80 backdrop-blur-sm shadow-md' : 'bg-transparent'}`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="text-2xl font-bold font-heading text-primary">
            Havenicstores
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <NavLink to="/" className={({ isActive }) => `font-semibold transition-colors ${isActive ? 'text-accent' : 'text-primary-light hover:text-accent'}`}>Home</NavLink>
            <NavLink to="/shop" className={({ isActive }) => `font-semibold transition-colors ${isActive ? 'text-accent' : 'text-primary-light hover:text-accent'}`}>Shop</NavLink>
          </nav>
          <div className="flex items-center gap-4">
            <SearchBar />
            <NavLink to="/account" className="text-primary-light hover:text-accent transition-colors">
              <UserIcon className="w-6 h-6" />
            </NavLink>
            <NavLink to="/cart" className="relative text-primary-light hover:text-accent transition-colors">
              <ShoppingCartIcon className="w-6 h-6" />
              {itemCount > 0 && (
                <span className="absolute -top-2 -right-2 flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-accent rounded-full">
                  {itemCount}
                </span>
              )}
            </NavLink>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
