
import React from 'react';
import { PlusIcon, MinusIcon } from './icons';

interface QuantitySelectorProps {
  quantity: number;
  onQuantityChange: (newQuantity: number) => void;
  max: number;
}

const QuantitySelector: React.FC<QuantitySelectorProps> = ({ quantity, onQuantityChange, max }) => {
  const increment = () => {
    if (quantity < max) {
      onQuantityChange(quantity + 1);
    }
  };

  const decrement = () => {
    if (quantity > 1) {
      onQuantityChange(quantity - 1);
    }
  };

  return (
    <div className="flex items-center border border-slate-300 rounded-lg">
      <button 
        onClick={decrement}
        disabled={quantity <= 1}
        className="px-3 py-2 text-primary-light hover:text-accent disabled:text-slate-300 transition-colors"
        aria-label="Decrease quantity"
      >
        <MinusIcon className="w-4 h-4" />
      </button>
      <span className="px-4 py-2 font-bold text-lg w-16 text-center">{quantity}</span>
      <button 
        onClick={increment}
        disabled={quantity >= max}
        className="px-3 py-2 text-primary-light hover:text-accent disabled:text-slate-300 transition-colors"
        aria-label="Increase quantity"
      >
        <PlusIcon className="w-4 h-4" />
      </button>
    </div>
  );
};

export default QuantitySelector;
