
import React from 'react';
import { StarIcon } from './icons';

interface ReviewStarsProps {
  rating: number;
  className?: string;
}

const ReviewStars: React.FC<ReviewStarsProps> = ({ rating, className }) => {
  return (
    <div className={`flex items-center gap-1 ${className}`}>
      {[...Array(5)].map((_, index) => (
        <StarIcon 
          key={index} 
          className={`w-5 h-5 ${index < Math.round(rating) ? 'text-yellow-400' : 'text-slate-300'}`}
        />
      ))}
    </div>
  );
};

export default ReviewStars;
