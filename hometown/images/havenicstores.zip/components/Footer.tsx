
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-primary text-slate-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-heading text-white font-semibold mb-4">Havenicstores</h3>
            <p className="text-sm">Your one-stop shop for curated, high-quality products that enhance your lifestyle.</p>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Shop</h4>
            <ul className="space-y-2">
              <li><Link to="/shop" className="text-sm hover:text-accent transition-colors">All Products</Link></li>
              <li><Link to="/shop" className="text-sm hover:text-accent transition-colors">Electronics</Link></li>
              <li><Link to="/shop" className="text-sm hover:text-accent transition-colors">Travel</Link></li>
              <li><Link to="/shop" className="text-sm hover:text-accent transition-colors">Lifestyle</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Account</h4>
            <ul className="space-y-2">
              <li><Link to="/account" className="text-sm hover:text-accent transition-colors">My Account</Link></li>
              <li><Link to="/cart" className="text-sm hover:text-accent transition-colors">My Cart</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Policies</h4>
            <ul className="space-y-2">
              <li><Link to="/shipping-policy" className="text-sm hover:text-accent transition-colors">Shipping Policy</Link></li>
              <li><Link to="/refund-policy" className="text-sm hover:text-accent transition-colors">Refund Policy</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-primary-light text-center text-sm">
          <p>&copy; {new Date().getFullYear()} Havenicstores. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
