
export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  images: string[];
  specs: Record<string, string>;
  reviews: Review[];
  orderCount: number;
  stock: number;
  category: string;
}

export interface CartItem extends Product {
  quantity: number;
}
