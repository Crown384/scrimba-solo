
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';

const CheckoutPage: React.FC = () => {
  const navigate = useNavigate();
  const { cart, totalPrice, clearCart } = useCart();

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would integrate with Stripe
    console.log("Processing payment...");
    clearCart();
    navigate('/confirmation');
  };
  
  return (
    <div className="bg-slate-100">
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold font-heading text-center mb-12">Checkout</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-4xl mx-auto">
          {/* Shipping Form */}
          <div className="bg-white p-8 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold font-heading mb-6">Shipping Information</h2>
            <form onSubmit={handleCheckout} className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-700">Email (for guest checkout)</label>
                <input type="email" id="email" required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-accent focus:border-accent" />
              </div>
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-700">Full Name</label>
                <input type="text" id="name" required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-accent focus:border-accent" />
              </div>
              <div>
                <label htmlFor="address" className="block text-sm font-medium text-slate-700">Address</label>
                <input type="text" id="address" required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-accent focus:border-accent" />
              </div>
              <div className="flex gap-4">
                  <div className="flex-1">
                      <label htmlFor="city" className="block text-sm font-medium text-slate-700">City</label>
                      <input type="text" id="city" required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-accent focus:border-accent" />
                  </div>
                  <div className="flex-1">
                      <label htmlFor="zip" className="block text-sm font-medium text-slate-700">ZIP Code</label>
                      <input type="text" id="zip" required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-accent focus:border-accent" />
                  </div>
              </div>

              {/* Mock Stripe Element */}
              <div className="pt-4">
                <h3 className="text-xl font-bold font-heading mb-4">Payment Details</h3>
                <div className="p-3 border border-slate-300 rounded-md bg-slate-50">
                    <p className="text-sm text-slate-600">Mock Stripe Payment Element</p>
                </div>
              </div>

              <button type="submit" className="w-full mt-6 bg-accent hover:bg-accent-hover text-white font-bold py-3 px-6 rounded-lg transition-colors duration-300">
                Pay ${totalPrice.toFixed(2)}
              </button>
            </form>
          </div>
          {/* Order Summary */}
          <div className="bg-white p-8 rounded-lg shadow-md self-start sticky top-28">
            <h2 className="text-2xl font-bold font-heading mb-6">Your Order</h2>
            <div className="space-y-4">
              {cart.map(item => (
                <div key={item.id} className="flex justify-between items-center text-sm">
                    <div className="flex items-center gap-3">
                        <img src={item.images[0]} alt={item.name} className="w-12 h-12 object-cover rounded-md"/>
                        <div>
                            <p className="font-semibold">{item.name}</p>
                            <p className="text-slate-500">Qty: {item.quantity}</p>
                        </div>
                    </div>
                    <span className="font-medium">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              <div className="border-t border-slate-200 pt-4 mt-4 space-y-2">
                 <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>${totalPrice.toFixed(2)}</span>
                 </div>
                 <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>$0.00</span>
                 </div>
                 <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span>${totalPrice.toFixed(2)}</span>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
