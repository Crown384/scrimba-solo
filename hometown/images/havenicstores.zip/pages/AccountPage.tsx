
import React, { useState } from 'react';

const AccountPage: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Mock auth state

  // Mock order history
  const orderHistory = [
    { id: 'ORD123', date: '2023-10-25', total: 120.00, status: 'Delivered' },
    { id: 'ORD124', date: '2023-11-05', total: 79.99, status: 'Shipped' },
  ];

  if (isLoggedIn) {
    return (
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold font-heading mb-8">My Account</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-2xl font-bold mb-4">Profile</h2>
              <p><strong>Name:</strong> John Doe</p>
              <p><strong>Email:</strong> john.doe@example.com</p>
              <button onClick={() => setIsLoggedIn(false)} className="mt-6 w-full bg-primary-light hover:bg-primary text-white font-bold py-2 px-4 rounded-lg transition-colors">
                Log Out
              </button>
            </div>
          </div>
          <div className="md:col-span-2">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-2xl font-bold mb-4">Order History</h2>
              <div className="space-y-4">
                {orderHistory.map(order => (
                  <div key={order.id} className="border border-slate-200 p-4 rounded-md flex justify-between items-center">
                    <div>
                      <p className="font-bold">{order.id}</p>
                      <p className="text-sm text-slate-500">{order.date}</p>
                    </div>
                    <p className="font-semibold">${order.total.toFixed(2)}</p>
                    <span className={`px-3 py-1 text-xs font-semibold rounded-full ${order.status === 'Delivered' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
                      {order.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Login/Signup Form
  return (
    <div className="container mx-auto px-4 py-20">
      <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-md">
        <h1 className="text-3xl font-bold font-heading text-center mb-6">Login or Sign Up</h1>
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); setIsLoggedIn(true); }}>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-slate-700">Email</label>
            <input type="email" id="email" required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-accent focus:border-accent" />
          </div>
          <div>
            <label htmlFor="password">Password</label>
            <input type="password" id="password" required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-accent focus:border-accent" />
          </div>
          <button type="submit" className="w-full bg-accent hover:bg-accent-hover text-white font-bold py-3 px-4 rounded-lg transition-colors">
            Login / Sign Up
          </button>
        </form>
      </div>
    </div>
  );
};

export default AccountPage;
