
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../services/api';
import type { Product } from '../types';
import ProductCard from '../components/ProductCard';

const HomePage: React.FC = () => {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const products = await api.getProducts();
        setFeaturedProducts(products.slice(0, 4));
      } catch (error) {
        console.error("Failed to fetch products:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-slate-200" style={{ backgroundImage: "url('https://picsum.photos/seed/hero/1600/600')", backgroundSize: 'cover', backgroundPosition: 'center' }}>
        <div className="container mx-auto px-4 py-24 md:py-40 text-center bg-black bg-opacity-40">
          <h1 className="text-4xl md:text-6xl font-bold font-heading text-white mb-4">Discover Your Next Favorite Thing</h1>
          <p className="text-lg md:text-xl text-slate-100 max-w-2xl mx-auto mb-8">Curated collections for a life well-lived. Quality, style, and innovation delivered to your door.</p>
          <Link to="/shop" className="bg-accent hover:bg-accent-hover text-white font-bold py-3 px-8 rounded-lg text-lg transition-colors duration-300">
            Shop Now
          </Link>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold font-heading text-center mb-10">Featured Products</h2>
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-md h-96 animate-pulse">
                    <div className="h-64 bg-slate-200 rounded-t-lg"></div>
                    <div className="p-4 space-y-3">
                        <div className="h-4 bg-slate-200 rounded"></div>
                        <div className="h-6 w-1/3 bg-slate-200 rounded"></div>
                    </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {featuredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default HomePage;
