
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api';
import type { Product } from '../types';
import { useCart } from '../context/CartContext';
import ReviewStars from '../components/ReviewStars';
import QuantitySelector from '../components/QuantitySelector';
import ProductCard from '../components/ProductCard';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [similarProducts, setSimilarProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  const [showNotification, setShowNotification] = useState(false);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;
      try {
        setLoading(true);
        const fetchedProduct = await api.getProductById(id);
        if (fetchedProduct) {
          setProduct(fetchedProduct);
          setSelectedImage(fetchedProduct.images[0]);
          const similar = await api.getSimilarProducts(fetchedProduct.category, fetchedProduct.id);
          setSimilarProducts(similar);
        }
      } catch (error) {
        console.error("Failed to fetch product:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
    // Scroll to top on product change
    window.scrollTo(0, 0);
  }, [id]);

  const handleAddToCart = () => {
    if (product) {
      addToCart(product, quantity);
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
    }
  };

  if (loading) {
    return <div className="text-center py-20">Loading product...</div>;
  }

  if (!product) {
    return <div className="text-center py-20">Product not found.</div>;
  }

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Main Product Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Image Gallery */}
        <div>
          <div className="aspect-square bg-white rounded-lg shadow-md overflow-hidden mb-4">
            <img src={selectedImage} alt={product.name} className="w-full h-full object-cover"/>
          </div>
          <div className="flex gap-2">
            {product.images.map((img, index) => (
              <div key={index} 
                className={`w-20 h-20 rounded-md overflow-hidden cursor-pointer border-2 ${selectedImage === img ? 'border-accent' : 'border-transparent'}`}
                onClick={() => setSelectedImage(img)}
              >
                <img src={img} alt={`${product.name} thumbnail ${index + 1}`} className="w-full h-full object-cover"/>
              </div>
            ))}
          </div>
        </div>

        {/* Product Details */}
        <div>
          <h1 className="text-4xl font-bold font-heading text-primary mb-2">{product.name}</h1>
          <div className="flex items-center gap-4 mb-4">
            {product.reviews.length > 0 && (
              <>
                <ReviewStars rating={product.reviews.reduce((acc, r) => acc + r.rating, 0) / product.reviews.length} />
                <span className="text-sm text-slate-500">({product.reviews.length} reviews)</span>
              </>
            )}
          </div>
          <p className="text-3xl font-bold text-accent mb-6">${product.price.toFixed(2)}</p>
          <p className="text-slate-600 mb-6">{product.description}</p>
          
          <div className="flex items-center gap-2 text-sm text-primary-light mb-4 font-semibold">
            <span>✓</span>
            <span>{product.orderCount} orders completed</span>
          </div>

          {product.stock < 30 && (
            <p className="text-red-500 font-bold mb-6 animate-pulse">Only {product.stock} left!</p>
          )}

          <div className="flex items-center gap-4 mb-6">
            <QuantitySelector quantity={quantity} onQuantityChange={setQuantity} max={product.stock} />
            <button onClick={handleAddToCart} className="flex-1 bg-accent hover:bg-accent-hover text-white font-bold py-3 px-6 rounded-lg transition-colors duration-300">
              Add to Cart
            </button>
          </div>
        </div>
      </div>

      {/* Tabs: Description, Specs, Reviews */}
      <div className="mt-16">
        <div className="border-b border-slate-200">
          <h2 className="text-2xl font-bold font-heading mb-4">About this item</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
          <div>
            <h3 className="font-semibold text-lg mb-2">Description</h3>
            <p className="text-slate-600">{product.description}</p>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">Specifications</h3>
            <ul className="space-y-2">
              {Object.entries(product.specs).map(([key, value]) => (
                <li key={key} className="flex justify-between text-sm">
                  <span className="text-slate-500">{key}</span>
                  <span className="font-medium text-primary">{value}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      {product.reviews.length > 0 && (
        <div className="mt-16">
          <h2 className="text-2xl font-bold font-heading mb-6">Customer Reviews</h2>
          <div className="space-y-6">
            {product.reviews.map(review => (
              <div key={review.id} className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-bold text-primary">{review.author}</p>
                  <ReviewStars rating={review.rating} />
                </div>
                <p className="text-slate-500 text-sm mb-3">{new Date(review.date).toLocaleDateString()}</p>
                <p className="text-slate-600">{review.comment}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* More Like This */}
      {similarProducts.length > 0 && (
        <div className="mt-16">
            <h2 className="text-2xl font-bold font-heading text-center mb-10">More like this</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-8">
                {similarProducts.map(p => (
                    <ProductCard key={p.id} product={p} />
                ))}
            </div>
        </div>
      )}
      
      {/* Add to Cart Notification */}
      {showNotification && (
          <div className="fixed bottom-5 right-5 bg-primary text-white py-3 px-6 rounded-lg shadow-lg animate-bounce">
              Item added to cart!
          </div>
      )}
    </div>
  );
};

export default ProductDetailPage;
