
import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircleIcon } from '../components/icons';

const OrderConfirmationPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-20 text-center">
      <div className="max-w-md mx-auto bg-white p-10 rounded-lg shadow-lg">
        <CheckCircleIcon className="w-20 h-20 text-green-500 mx-auto mb-6" />
        <h1 className="text-3xl font-bold font-heading mb-4">Thank You For Your Order!</h1>
        <p className="text-slate-600 mb-8">
          Your order has been placed successfully. You will receive an email confirmation shortly with your order details.
        </p>
        <Link to="/shop" className="bg-accent hover:bg-accent-hover text-white font-bold py-3 px-8 rounded-lg transition-colors">
          Continue Shopping
        </Link>
      </div>
    </div>
  );
};

export default OrderConfirmationPage;
