
import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import type { Product } from '../types';
import ProductCard from '../components/ProductCard';

const ShopPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const allProducts = await api.getProducts();
        setProducts(allProducts);
      } catch (error) {
        console.error("Failed to fetch products:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold font-heading text-center mb-12">All Products</h1>
      
      {/* Filters (UI only) */}
      <div className="flex justify-center gap-4 mb-10">
        <select className="border border-slate-300 rounded-lg px-4 py-2 focus:outline-none focus:border-accent">
          <option>Category</option>
          <option>Electronics</option>
          <option>Travel</option>
          <option>Lifestyle</option>
        </select>
        <select className="border border-slate-300 rounded-lg px-4 py-2 focus:outline-none focus:border-accent">
          <option>Price</option>
          <option>Under $50</option>
          <option>$50 - $100</option>
          <option>Over $100</option>
        </select>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {[...Array(8)].map((_, i) => (
             <div key={i} className="bg-white rounded-lg shadow-md h-96 animate-pulse">
                <div className="h-64 bg-slate-200 rounded-t-lg"></div>
                <div className="p-4 space-y-3">
                    <div className="h-4 bg-slate-200 rounded"></div>
                    <div className="h-6 w-1/3 bg-slate-200 rounded"></div>
                </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {products.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ShopPage;
