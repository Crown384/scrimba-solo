
import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import QuantitySelector from '../components/QuantitySelector';
import { XIcon } from '../components/icons';

const CartPage: React.FC = () => {
  const { cart, updateQuantity, removeFromCart, totalPrice, itemCount } = useCart();

  if (itemCount === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="text-4xl font-bold font-heading mb-4">Your Cart is Empty</h1>
        <p className="text-slate-600 mb-8">Looks like you haven't added anything to your cart yet.</p>
        <Link to="/shop" className="bg-accent hover:bg-accent-hover text-white font-bold py-3 px-8 rounded-lg transition-colors">
          Start Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold font-heading mb-8">Your Cart</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
          <div className="space-y-6">
            {cart.map(item => (
              <div key={item.id} className="flex items-center gap-4 border-b border-slate-200 pb-6 last:border-b-0">
                <img src={item.images[0]} alt={item.name} className="w-24 h-24 object-cover rounded-md"/>
                <div className="flex-grow">
                  <Link to={`/product/${item.id}`} className="font-semibold text-lg hover:text-accent">{item.name}</Link>
                  <p className="text-sm text-slate-500">${item.price.toFixed(2)}</p>
                </div>
                <QuantitySelector 
                  quantity={item.quantity} 
                  onQuantityChange={(newQuantity) => updateQuantity(item.id, newQuantity)}
                  max={item.stock}
                />
                <p className="font-bold w-24 text-right">${(item.price * item.quantity).toFixed(2)}</p>
                <button onClick={() => removeFromCart(item.id)} className="text-slate-400 hover:text-red-500">
                  <XIcon className="w-6 h-6"/>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
            <div className="bg-white p-6 rounded-lg shadow-md sticky top-28">
                <h2 className="text-2xl font-bold font-heading mb-6">Order Summary</h2>
                <div className="space-y-4">
                    <div className="flex justify-between">
                        <span className="text-slate-600">Subtotal ({itemCount} items)</span>
                        <span className="font-semibold">${totalPrice.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-slate-600">Shipping</span>
                        <span className="font-semibold">FREE</span>
                    </div>
                    <div className="border-t border-slate-200 my-4"></div>
                    <div className="flex justify-between text-xl font-bold">
                        <span>Total</span>
                        <span>${totalPrice.toFixed(2)}</span>
                    </div>
                </div>
                <Link to="/checkout" className="mt-6 w-full text-center bg-accent hover:bg-accent-hover text-white font-bold py-3 px-6 rounded-lg transition-colors duration-300 block">
                    Proceed to Checkout
                </Link>
            </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
