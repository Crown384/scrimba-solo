
import React from 'react';

interface PolicyPageProps {
  type: 'shipping' | 'refund';
}

const policies = {
  shipping: {
    title: 'Shipping Policy',
    content: (
      <>
        <p className="mb-4">We are committed to getting your order to you as quickly as possible. All orders are processed within 1-2 business days. We offer standard and expedited shipping options at checkout.</p>
        <h3 className="text-xl font-semibold mb-2 mt-6">Shipping Rates & Delivery Estimates</h3>
        <p className="mb-4">Shipping charges for your order will be calculated and displayed at checkout. Delivery delays can occasionally occur.</p>
        <ul className="list-disc list-inside space-y-2">
          <li><strong>Standard Shipping:</strong> 5-7 business days</li>
          <li><strong>Expedited Shipping:</strong> 2-3 business days</li>
        </ul>
        <h3 className="text-xl font-semibold mb-2 mt-6">Shipment Confirmation & Order Tracking</h3>
        <p>You will receive a shipment confirmation email once your order has shipped containing your tracking number(s).</p>
      </>
    )
  },
  refund: {
    title: 'Refund Policy',
    content: (
      <>
        <p className="mb-4">We have a 30-day return policy, which means you have 30 days after receiving your item to request a return. To be eligible for a return, your item must be in the same condition that you received it, unworn or unused, with tags, and in its original packaging.</p>
        <h3 className="text-xl font-semibold mb-2 mt-6">How to Start a Return</h3>
        <p className="mb-4">To start a return, you can contact us at support@havenicstores.com. If your return is accepted, we’ll send you a return shipping label, as well as instructions on how and where to send your package.</p>
        <h3 className="text-xl font-semibold mb-2 mt-6">Refunds</h3>
        <p>We will notify you once we’ve received and inspected your return, and let you know if the refund was approved or not. If approved, you’ll be automatically refunded on your original payment method. Please remember it can take some time for your bank or credit card company to process and post the refund too.</p>
      </>
    )
  }
};

const PolicyPage: React.FC<PolicyPageProps> = ({ type }) => {
  const policy = policies[type];

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-md">
        <h1 className="text-4xl font-bold font-heading mb-8">{policy.title}</h1>
        <div className="prose max-w-none text-slate-600">
          {policy.content}
        </div>
      </div>
    </div>
  );
};

export default PolicyPage;
