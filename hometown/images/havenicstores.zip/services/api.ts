
import type { Product } from '../types';

const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Aura Wireless Earbuds',
    price: 79.99,
    description: 'Experience immersive sound with the Aura Wireless Earbuds. Featuring active noise cancellation, a comfortable fit, and a sleek charging case, they are your perfect audio companion for any activity.',
    images: [
      'https://picsum.photos/seed/product1-1/800/800',
      'https://picsum.photos/seed/product1-2/800/800',
      'https://picsum.photos/seed/product1-3/800/800',
    ],
    specs: { 'Connectivity': 'Bluetooth 5.2', 'Playtime': '8 hours', 'Charging': 'USB-C', 'Water Resistance': 'IPX4' },
    reviews: [
      { id: 'r1', author: 'Jane D.', rating: 5, comment: 'Amazing sound quality and they fit perfectly!', date: '2023-10-15' },
      { id: 'r2', author: 'John S.', rating: 4, comment: 'Great for the price, noise cancellation is decent.', date: '2023-10-12' },
    ],
    orderCount: 1245,
    stock: 23,
    category: 'Electronics',
  },
  {
    id: '2',
    name: 'Terra Adventure Backpack',
    price: 120.00,
    description: 'Built for the modern explorer, the Terra Adventure Backpack is durable, water-resistant, and features multiple compartments, including a padded laptop sleeve. Ready for your next journey, urban or wild.',
    images: [
      'https://picsum.photos/seed/product2-1/800/800',
      'https://picsum.photos/seed/product2-2/800/800',
    ],
    specs: { 'Material': 'Recycled Nylon', 'Capacity': '25L', 'Weight': '0.8kg', 'Laptop Sleeve': 'Up to 15-inch' },
    reviews: [
      { id: 'r3', author: 'Alex R.', rating: 5, comment: 'Took this on a hike and it was perfect. So many useful pockets.', date: '2023-09-20' },
    ],
    orderCount: 832,
    stock: 5,
    category: 'Travel',
  },
  {
    id: '3',
    name: 'Solstice Smart Watch',
    price: 199.50,
    description: 'Track your fitness, stay connected with notifications, and customize your watch face with the Solstice Smart Watch. A blend of style and technology, it features a vibrant AMOLED display and a long-lasting battery.',
    images: [
      'https://picsum.photos/seed/product3-1/800/800',
      'https://picsum.photos/seed/product3-2/800/800',
      'https://picsum.photos/seed/product3-3/800/800',
    ],
    specs: { 'Display': '1.4" AMOLED', 'Sensors': 'Heart Rate, GPS', 'Battery Life': '7 days', 'Compatibility': 'iOS & Android' },
    reviews: [],
    orderCount: 450,
    stock: 12,
    category: 'Electronics',
  },
  {
    id: '4',
    name: 'HydroFlow Insulated Bottle',
    price: 35.00,
    description: 'Keep your drinks cold for 24 hours or hot for 12 with the HydroFlow Insulated Bottle. Made from premium stainless steel, it\'s leak-proof and features a durable powder-coat finish.',
    images: [
      'https://picsum.photos/seed/product4-1/800/800',
      'https://picsum.photos/seed/product4-2/800/800',
    ],
    specs: { 'Capacity': '32oz (950ml)', 'Material': '18/8 Stainless Steel', 'Insulation': 'Double-Wall Vacuum', 'Mouth': 'Wide Mouth' },
    reviews: [
      { id: 'r4', author: 'Emily C.', rating: 5, comment: 'Best water bottle I have ever owned. Ice stays frozen all day!', date: '2023-11-01' },
      { id: 'r5', author: 'Mark T.', rating: 5, comment: 'Durable and the color is great.', date: '2023-10-28' },
    ],
    orderCount: 3102,
    stock: 50,
    category: 'Lifestyle',
  },
];

export const api = {
  getProducts: async (): Promise<Product[]> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockProducts;
  },
  getProductById: async (id: string): Promise<Product | undefined> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return mockProducts.find(p => p.id === id);
  },
  getSimilarProducts: async (categoryId: string, currentProductId: string): Promise<Product[]> => {
    await new Promise(resolve => setTimeout(resolve, 400));
    return mockProducts.filter(p => p.category === categoryId && p.id !== currentProductId).slice(0, 2);
  },
  searchProducts: async (query: string): Promise<Product[]> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    if (!query) return [];
    const lowerCaseQuery = query.toLowerCase();
    return mockProducts.filter(p => p.name.toLowerCase().includes(lowerCaseQuery));
  },
};
